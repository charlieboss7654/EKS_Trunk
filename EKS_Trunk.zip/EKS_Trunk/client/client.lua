local inTrunk = false
local trunkVeh = nil
local exitKey = 23 
local doorIndexTrunk = 5 

local function openTrunk(veh, open)
    if open then
        SetVehicleDoorOpen(veh, doorIndexTrunk, false, false)
    else
        SetVehicleDoorShut(veh, doorIndexTrunk, false)
    end
end

local function getTrunkAttachOffset(veh)
    local boneIndex = GetEntityBoneIndexByName(veh, 'boot')
    if boneIndex ~= -1 then
        return boneIndex, vec3(0.0, 0.35, 0.1), vec3(0.0, 0.0, 180.0)
    else
        local min, max = GetModelDimensions(GetEntityModel(veh))
        local fallback = vec3(0.0, min.y + ((max.y - min.y) * 0.15), 0.1)
        return 0, fallback, vec3(0.0, 0.0, 180.0)
    end
end

local function hidePed(ped)
    SetEntityVisible(ped, false, false)
    SetEntityAlpha(ped, 0, false)
    SetEntityCollision(ped, false, true)
    SetPedCanRagdoll(ped, false)
    DisablePedPainAudio(ped, true)
    if NetworkDoesNetworkIdExist(NetworkGetNetworkIdFromEntity(ped)) then
        NetworkSetEntityInvisibleToNetwork(ped, true)
    end
end

local function unhidePed(ped)
    SetEntityVisible(ped, true, false)
    ResetEntityAlpha(ped)
    SetEntityCollision(ped, true, true)
    SetPedCanRagdoll(ped, true)
    DisablePedPainAudio(ped, false)
    if NetworkDoesNetworkIdExist(NetworkGetNetworkIdFromEntity(ped)) then
        NetworkSetEntityInvisibleToNetwork(ped, false)
    end
end

local function forceExitCleanup()
    if inTrunk then
        DetachEntity(cache.ped, true, true)
        ClearPedTasksImmediately(cache.ped)
        unhidePed(cache.ped)
        inTrunk = false
        trunkVeh = nil
    end
end

local function enterTrunk(veh)
    if inTrunk or not DoesEntityExist(veh) then return end
    if IsPedInAnyVehicle(cache.ped, false) then return end

    openTrunk(veh, true)
    Wait(400)

    local boneIndex, offset, rot = getTrunkAttachOffset(veh)

    ClearPedTasksImmediately(cache.ped)
    hidePed(cache.ped)

    AttachEntityToEntity(
        cache.ped, veh, boneIndex,
        offset.x, offset.y, offset.z,
        rot.x, rot.y, rot.z,
        false, false, true, false, 2, true
    )

    inTrunk = true
    trunkVeh  = veh

    Wait(800)
    openTrunk(veh, false)

    CreateThread(function()
        while inTrunk do
            if not DoesEntityExist(trunkVeh) or IsEntityDead(trunkVeh) then
                forceExitCleanup()
                break
            end

            if IsControlJustPressed(0, exitKey) then
                openTrunk(trunkVeh, true)
                Wait(250)

                local vPos = GetEntityCoords(trunkVeh)
                local vFwd = GetEntityForwardVector(trunkVeh)
                local exitPos = vPos - (vFwd * 2.0)

                DetachEntity(cache.ped, true, true)
                unhidePed(cache.ped)
                SetEntityCoordsNoOffset(cache.ped, exitPos.x, exitPos.y, exitPos.z, false, false, false)

                Wait(700)
                if DoesEntityExist(trunkVeh) then
                    openTrunk(trunkVeh, false)
                end

                inTrunk = false
                trunkVeh = nil
                break
            end

            DisableControlAction(0, 140, true)
            DisableControlAction(0, 141, true)
            DisableControlAction(0, 142, true)
            DisableControlAction(0, 36,  true)
            Wait(0)
        end
    end)
end

CreateThread(function()
    if not pcall(function() return exports.ox_target end) then
        print('^1[EKS_HideInTrunk]^7 ox_target not found. Ensure ox_target before this resource.')
        return
    end

    exports.ox_target:addGlobalVehicle({
        {
            name = 'eks_hide_in_trunk',
            icon = 'fa-solid fa-box-archive',
            label = 'Hide in trunk',
            bones = { 'boot' },
            distance = 2.0,
            canInteract = function(entity)
                if inTrunk then return false end
                if not DoesEntityExist(entity) then return false end
                if IsPedInAnyVehicle(cache.ped, false) then return false end
                if GetNumberOfVehicleDoors(entity) < 5 then return false end
                return true
            end,
            onSelect = function(data)
                enterTrunk(data.entity)
            end
        }
    })
end)

AddEventHandler('baseevents:onPlayerDied', forceExitCleanup)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        forceExitCleanup()
    end
end)
