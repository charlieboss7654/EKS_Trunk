fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS_HideInTrunk'
author 'R.Robertson - Echo Kilo Studios'
description 'Third Eye boot hiding!'
version '1.0.0'

shared_script '@ox_lib/init.lua'
client_script 'client/client.lua'
